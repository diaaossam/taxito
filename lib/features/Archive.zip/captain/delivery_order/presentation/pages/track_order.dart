import 'package:taxito/core/extensions/app_localizations_extension.dart';
import 'package:taxito/features/captain/delivery_order/presentation/cubit/track/track_order_cubit.dart';
import 'package:taxito/features/captain/delivery_order/presentation/widgets/track_order/track_order_body.dart';
import 'package:taxito/widgets/custom_app_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../../config/dependencies/injectable_dependencies.dart';

class TrackOrderScreen extends StatelessWidget {
  final num id;

  const TrackOrderScreen({super.key, required this.id});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => sl<TrackOrderCubit>()..getOrderDetails(orderId: id),
      child: Scaffold(
        appBar: CustomAppBar(
          title: context.localizations.trackOrder,
        ),
        body: const TrackOrderBody(),
      ),
    );
  }
}
