part of 'trip_history_cubit.dart';

@immutable
sealed class TripHistoryState {}

final class TripHistoryInitial extends TripHistoryState {}
